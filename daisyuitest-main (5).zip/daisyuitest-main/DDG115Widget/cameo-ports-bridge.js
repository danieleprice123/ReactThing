// cameo-ports-bridge.js
// Bridge your React app <-> CST "Custom HTML widget" DOM ports (paths="...").
// Works with body[class="widget"][paths="@paths@"] and child elements that
// declare `paths="desiredSpeed"`, `paths="totalFuelLoad"`, `paths="SetCondition1"`.

(function () {
  // ---- helpers --------------------------------------------------------------
  const q = (sel) => document.querySelector(sel);

  // Find a DOM port by its CST "paths" name (value port or operation port)
  function findPort(name) {
    return document.querySelector(`[paths="${name}"]`);
  }

  // Normalize numeric-ish values; return number or null
  function toNumberOrNull(v) {
    if (v == null || v === "") return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }

  // Dispatch a 'change' so CST notices the value has changed
  function fireChange(el) {
    // bubbles: true so any CST listeners up the tree can catch it
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // Watch an input for value changes coming FROM CST (some CST setups assign .value
  // without firing 'change'); so we listen to 'change' and also observe mutations.
  function watchPort(el, onUpdate) {
    if (!el) return () => {};

    const handler = () => onUpdate(toNumberOrNull(el.value));

    el.addEventListener("change", handler);
    el.addEventListener("input", handler); // some runtimes emit input

    // Mutation observer as a fallback if runtime sets attributes/props silently
    const mo = new MutationObserver(() => handler());
    mo.observe(el, { attributes: true, attributeFilter: ["value"] });

    // Initial push if pre-populated
    if (el.value !== "") handler();

    return () => {
      el.removeEventListener("change", handler);
      el.removeEventListener("input", handler);
      mo.disconnect();
    };
  }

  // ---- bind the three ports you care about ---------------------------------
  const port_desiredSpeed = findPort("desiredSpeed");   // <input paths="desiredSpeed">
  const port_totalFuelLoad = findPort("totalFuelLoad"); // <input paths="totalFuelLoad">
  const op_SetCondition1 = findPort("SetCondition1");   // <button paths="SetCondition1">

  if (!port_desiredSpeed) console.warn("[CST Bridge] Missing value port: desiredSpeed");
  if (!port_totalFuelLoad) console.warn("[CST Bridge] Missing value port: totalFuelLoad");
  if (!op_SetCondition1)   console.warn("[CST Bridge] Missing operation port: SetCondition1");

  // ---- public API the React app will call ----------------------------------
  // (These names match the ones we used in App.jsx)
  window.cst = {
    // App -> CST: set a value
    setValue(name, value) {
      const el = findPort(name);
      if (!el) return;
      const next = value == null ? "" : String(value);
      if (el.value !== next) {
        el.value = next;
        fireChange(el); // let CST runtime see the update
      }
    },

    // CST -> App: subscribe to a value
    onValue(name, cb) {
      const el = findPort(name);
      if (!el) {
        console.warn(`[CST Bridge] onValue(): port not found: ${name}`);
        return () => {};
      }
      return watchPort(el, cb);
    },

    // App -> CST: call an operation
    callOperation(opName, payload) {
      const btn = findPort(opName);
      if (!btn) {
        console.warn(`[CST Bridge] callOperation(): op not found: ${opName}`);
        return;
      }
      // If you ever need to pass a payload, you can set data-* attrs first:
      // for (const [k,v] of Object.entries(payload||{})) btn.dataset[k] = String(v);
      btn.click();
    },
  };

  // Optional: debug tracing (comment out if noisy)
  if (port_desiredSpeed) {
    port_desiredSpeed.addEventListener("change", () =>
      console.log("[CST Bridge] desiredSpeed ->", port_desiredSpeed.value)
    );
  }
  if (port_totalFuelLoad) {
    port_totalFuelLoad.addEventListener("change", () =>
      console.log("[CST Bridge] totalFuelLoad ->", port_totalFuelLoad.value)
    );
  }
  if (op_SetCondition1) {
    op_SetCondition1.addEventListener("click", () =>
      console.log("[CST Bridge] SetCondition1 clicked")
    );
  }
})();
