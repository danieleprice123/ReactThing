import "./App.css";
import React from "react";

export default function App() {
  const [speed, setSpeed] = React.useState(30);
  const clamp = (n) => Math.max(0, Math.min(30, n));

  const onSliderChange = (e) => setSpeed(clamp(Number(e.target.value)));
  const onInputChange = (e) => {
    const v = e.target.value;
    if (v === "") return setSpeed(0);
    setSpeed(clamp(Number(v)));
  };

  return (
    <div className="min-h-screen bg-base-200 text-base-content">
      <header className="mb-6 ml-12">
        <h1 className="text-3xl lg:text-4xl font-semibold tracking-tight">DDG 115</h1>
        <p className="opacity-70 ml-4">Real-time platform status</p>
      </header>

      <main className="container mx-auto max-w-7xl p-4 lg:p-6">
        {/* Mission Profile */}
        <section className="card bg-base-100 shadow mb-6">
          <div className="card-body">
            <h2 className="card-title">Mission Profile</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-4">
              <div className="stat">
                <div className="stat-title">Speed</div>
                <div className="stat-value">
                  {speed} <span className="text-2xl">knts</span>
                </div>
              </div>
              <div className="stat">
                <div className="stat-title">Propulsion</div>
                <div className="stat-value text-sm">Trail Shaft</div>
              </div>
              <div className="stat">
                <div className="stat-title">Fuel</div>
                <div className="stat-value">100%</div>
              </div>
              <div className="stat">
                <div className="stat-title">Range</div>
                <div className="stat-value">
                  200 <span className="text-2xl">nmi</span>
                </div>
              </div>
              <div className="stat">
                <div className="stat-title">Endurance</div>
                <div className="stat-value">
                  300 <span className="text-2xl">hrs</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 3-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column (trimmed examples) */}
          <div className="flex flex-col gap-6">
            <div className="card bg-base-100 shadow">
              <div className="card-body">
                <h2 className="card-title">Aux Systems</h2>
                <div className="flex items-end justify-between">
                  <span className="opacity-70">Total Power</span>
                  <span className="text-2xl font-semibold tabular-nums">420 kW</span>
                </div>
                <progress className="progress progress-primary" value={65} max="100"></progress>
                <div className="text-xs opacity-70">Load 65%</div>
              </div>
            </div>

            <div className="card bg-base-100 shadow">
              <div className="card-body">
                <h2 className="card-title">Armament Systems</h2>
                <div className="flex items-end justify-between">
                  <span className="opacity-70">Total Power</span>
                  <span className="text-2xl font-semibold tabular-nums">310 kW</span>
                </div>
                <progress className="progress progress-secondary" value={42} max="100"></progress>
                <div className="text-xs opacity-70">Load 42%</div>
              </div>
            </div>

            <div className="card bg-base-100 shadow">
              <div className="card-body">
                <h2 className="card-title">Energy Summary</h2>
                <div className="stats shadow">
                  <div className="stat">
                    <div className="stat-title">Fuel Load</div>
                    <div className="stat-value text-primary">
                      200 <span className="text-2xl">kgal</span>
                    </div>
                    <div className="stat-desc">JP-5 reserve nominal</div>
                  </div>
                  <div className="stat">
                    <div className="stat-title">Total Power</div>
                    <div className="stat-value">
                      1.21 <span className="text-2xl">kW</span>
                    </div>
                  </div>
                  <div className="stat">
                    <div className="stat-title">Energy Consumed</div>
                    <div className="stat-value">
                      88 <span className="text-2xl">kWh</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Middle column — Rails + Telegraph */}
          <TelegraphWithRails speed={speed} setSpeed={(v)=>setSpeed(clamp(v))} />

          {/* Right column (trimmed examples) */}
          <div className="flex flex-col gap-6">
            <div className="card bg-base-100 shadow">
              <div className="card-body">
                <div className="flex items-center justify-between">
                  <h3 className="card-title">Elect Plot</h3>
                  <span className="badge">kW</span>
                </div>
                <svg viewBox="0 0 300 120" className="w-full h-40 text-primary mt-2">
                  <g className="chart-grid" strokeWidth="1">
                    <line x1="0" y1="20" x2="300" y2="20" />
                    <line x1="0" y1="60" x2="300" y2="60" />
                    <line x1="0" y1="100" x2="300" y2="100" />
                  </g>
                  <path className="chart-path" d="M0,90 C40,80 60,70 90,75 S150,55 180,60 240,40 300,50" />
                </svg>
              </div>
            </div>

            <div className="card bg-base-100 shadow">
              <div className="card-body">
                <div className="flex items-center justify-between">
                  <h3 className="card-title">Fuel Plot</h3>
                  <span className="badge">%</span>
                </div>
                <svg viewBox="0 0 300 120" className="w-full h-40 text-secondary mt-2">
                  <g className="chart-grid" strokeWidth="1">
                    <line x1="0" y1="20" x2="300" y2="20" />
                    <line x1="0" y1="60" x2="300" y2="60" />
                    <line x1="0" y1="100" x2="300" y2="100" />
                  </g>
                  <path className="chart-path" d="M0,30 L60,35 120,40 180,55 240,80 300,95" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <section className="card bg-base-100 shadow mt-6">
          <div className="card-body">
            <h2 className="card-title">Commanded Speed</h2>
            <div className="flex flex-col gap-3 items-start">
              <div className="flex items-center gap-2">
                <label htmlFor="speedInput" className="opacity-70 text-sm">Enter Speed:</label>
                <input
                  id="speedInput" type="number" min="0" max="30"
                  value={speed} onChange={onInputChange}
                  className="input input-bordered input-sm w-24"
                />
              </div>
              <div className="w-full max-w-sm">
                <input
                  id="speedRange" type="range" min="0" max="30"
                  value={speed} onChange={onSliderChange}
                  className="range range-primary w-full"
                />
                <div className="flex justify-between text-sm opacity-70 px-1">
                  <span>0</span><span>10</span><span>20</span><span>30</span>
                </div>
              </div>
              <button className="btn btn-primary" onClick={() => window.callSetCondition1 && window.callSetCondition1()}>
                Set Condition 1
              </button>
              <div className="flex items-center gap-3">
                <span className="opacity-70">Value</span>
                <div className="kbd kbd-sm"><span>{speed}</span> knts</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer footer-center p-6 bg-base-100 text-base-content/70">
        <aside>
          <p>© {new Date().getFullYear()} Systems Dashboard — Built with Tailwind CSS & DaisyUI</p>
        </aside>
      </footer>
    </div>
  );
}

/* ==================== TELEGRAPH WITH RAILS ==================== */

function TelegraphWithRails({ speed, setSpeed }) {
  // top -> bottom
  const ORDER = [
    { id:"flank",    label:<>Flank</>,                     spd:28, className:"tele-item tele-ahead h-tele-xl"  },
    { id:"full",     label:<><span>Ahead</span><span>Full</span></>, spd:25, className:"tele-item tele-ahead flex flex-col items-center leading-[1.05] h-tele-xxl" },
    { id:"standard", label:<>Std</>,                       spd:20, className:"tele-item tele-ahead h-tele-lg"  },
    { id:"ahead23",  label:<><span>Ahead</span><span>2/3</span></>, spd:18, className:"tele-item tele-ahead flex flex-col items-center leading-[1.05] h-tele-md" },
    { id:"ahead13",  label:<><span>Ahead</span><span>1/3</span></>, spd:10, className:"tele-item tele-ahead flex flex-col items-center leading-[1.05] h-tele-sm" },
    { id:"stop",     label:<>Stop</>,                      spd: 0, className:"tele-item tele-stop h-tele-stop" }
  ];

  const stackRef = React.useRef(null);
  const btnRefs  = React.useRef([]);
  const [heights, setHeights] = React.useState([]);
  const [stackPx, setStackPx] = React.useState(0);
  const [fillPx, setFillPx]   = React.useState(0);

  // Insets used by CSS for the rail track
  const INSET_TOP = 8, INSET_BOTTOM = 8;

  // measure actual DOM heights so rails align exactly to what’s rendered
  const measure = React.useCallback(() => {
    const hs = btnRefs.current.map((el) => el?.getBoundingClientRect().height || 0);
    setHeights(hs);
    setStackPx(hs.reduce((a,b)=>a+b, 0));
  }, []);

  React.useLayoutEffect(() => { measure(); }, [measure]);
  React.useEffect(() => {
    const ro = new ResizeObserver(measure);
    if (stackRef.current) ro.observe(stackRef.current);
    return () => ro.disconnect();
  }, [measure]);

  // ----- Ticks: 0..10 with "10" 25% down from Flank top -----
  const ticks = React.useMemo(() => {
    if (!heights.length) return [];
    const stopMid = heights[heights.length-1] * 0.5;
    const flankH  = heights[0];
    const topHeadroom = flankH * 0.25;            // 25% down from Flank top

    const usable = (stackPx - topHeadroom) - stopMid; // space from 10 down to 0
    const trackH = stackPx; // inner track == stack height

    return Array.from({ length: 11 }, (_, i) => {
      const yFromBottom = stopMid + usable * (i / 10); // inside track coords (bottom-based)
      const topPx = INSET_TOP + (trackH - yFromBottom);
      return { value: i, bottomPx: yFromBottom, topPx };
    });
  }, [heights, stackPx]);

  // ----- Green fill: halfway, except Flank aligns to the "10" tick -----
  React.useEffect(() => {
    if (!heights.length) return;

    // find active order index (closest speed)
    let activeIdx = 0, best = Infinity;
    ORDER.forEach((o,i) => { const d = Math.abs(speed - o.spd); if (d < best){best=d; activeIdx=i;} });

    // sum rows below active
    let sum = 0;
    for (let i = ORDER.length - 1; i > activeIdx; i--) sum += heights[i];

    if (ORDER[activeIdx].id === "flank") {
      // special case: align to the "10" tick center
      const tick10 = ticks.find(t => t.value === 10);
      if (tick10) {
        setFillPx(tick10.bottomPx-5);
        return;
      }
    }

    // normal behavior: halfway into the active button
    sum += heights[activeIdx] * 0.5;
    setFillPx(sum);
  }, [speed, heights, ticks]);

  const isActive = (target, lower, upper) =>
    (Math.abs(speed - target) < Math.abs(speed - lower)) &&
    (Math.abs(speed - target) <= Math.abs(speed - upper));

  return (
    <div className="tele-rails self-start h-fit">
      {/* Left rail (ticks & labels inboard, between rail and telegraph) */}
      <Rail side="left" stackPx={stackPx} insetTop={INSET_TOP} insetBottom={INSET_BOTTOM} fillPx={fillPx} ticks={ticks} />

      {/* Telegraph bezel + stack */}
      <div className="telegraph w-[12rem]">
        <div ref={stackRef} className="tele-stack">
          {ORDER.map((o, idx) => (
            <button
              key={o.id}
              ref={el => (btnRefs.current[idx] = el)}
              type="button"
              onClick={() => setSpeed(o.spd)}
              className={[
                o.className,
                o.id === "flank"   && Math.abs(speed-28)<=Math.abs(speed-25) ? "tele-active" : "",
                o.id === "full"    && isActive(25,28,20) ? "tele-active" : "",
                o.id === "standard"&& isActive(20,25,18) ? "tele-active" : "",
                o.id === "ahead23" && isActive(18,20,10) ? "tele-active" : "",
                o.id === "ahead13" && isActive(10,18,0)  ? "tele-active" : "",
                o.id === "stop"    && Math.abs(speed-0) < Math.abs(speed-10) ? "tele-active" : ""
              ].join(" ")}
              title={`${o.id} (${o.spd} kts)`}
            >
              {o.label}
            </button>
          ))}
        </div>
      </div>

      {/* Right rail */}
      <Rail side="right" stackPx={stackPx} insetTop={INSET_TOP} insetBottom={INSET_BOTTOM} fillPx={fillPx} ticks={ticks} />
    </div>
  );
}

function Rail({ side, stackPx, insetTop, insetBottom, fillPx, ticks }) {
  const outerH = stackPx + insetTop + insetBottom;

  return (
    <div className={`rail rail--${side}`} style={{ height: `${outerH}px` }}>
      <div className="rail-track" />
      <div className="rail-fill" style={{ height: `${fillPx}px` }} />
      <div className="rail-scale">
        {ticks.map((t, i) => {
          const strong = i % 5 === 0;
          const style = { top: `${t.topPx}px` }; // labels centered via CSS
          return (
            <React.Fragment key={i}>
              <div className={`rail-tick ${strong ? "strong" : ""}`} style={style} />
              <div className="rail-label" style={style}>{t.value}</div>
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
